// Copyright (c) ppy Pty Ltd <contact@ppy.sh>. Licensed under the MIT Licence.
// See the LICENCE file in the repository root for full licence text.

#nullable disable

using Android;
using Android.App;

// used for AndroidBatteryInfo
[assembly: UsesPermission(Manifest.Permission.BatteryStats)]
